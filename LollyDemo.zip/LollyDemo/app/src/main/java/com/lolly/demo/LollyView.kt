package com.lolly.demo

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.*
import kotlin.random.Random

class LollyView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val brain = Brain()
    private val renderer: CharacterRenderer = ShapeRenderer(d)   // <- swap for a PNG renderer later
    private val st = CharacterState()
    private val bg = Paint(); private val hud = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = 13f * d }
    private val tops = intArrayOf(0xFFCFE8F5.toInt(), 0xFFF2B48F.toInt(), 0xFF1D2340.toInt())
    private val bots = intArrayOf(0xFFFBF1DD.toInt(), 0xFFD9C3E6.toInt(), 0xFF3B3560.toInt())
    private var curTop = tops[0]; private var curBot = bots[0]
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var ready = false; private var last = 0L
    private var tx = 0f; private var ty = 0f; private var fx = 0f; private var fy = 0f
    private var pressed = false; private var dragging = false
    private var downX = 0f; private var downY = 0f; private var offX = 0f; private var offY = 0f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (!ready) { st.x = w / 2f; st.y = h * 0.7f; ready = true; brain.start(Behavior.IDLE) }
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(s: Int) = (((a shr s) and 255) + (((b shr s) and 255) - ((a shr s) and 255)) * t).toInt()
        return (ch(24) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    private fun begin(b: Behavior) {
        brain.start(b); st.behavior = b; st.time = 0f
        if (b == Behavior.WALK) pickTarget()
    }

    private fun pickTarget() {
        val minX = 70f * d; val maxX = width - 70f * d; val minY = height * 0.5f; val maxY = height * 0.88f
        repeat(10) {
            tx = minX + Random.nextFloat() * (maxX - minX); ty = minY + Random.nextFloat() * (maxY - minY)
            if (hypot(tx - st.x, ty - st.y) > 120f * d) return
        }
    }

    private fun step(dt: Float) {
        val p = brain.period().ordinal
        val k = 1f - exp(-dt * 1.5f)
        curTop = mix(curTop, tops[p], k); curBot = mix(curBot, bots[p], k)
        st.time += dt
        when (st.behavior) {
            Behavior.WALK -> {
                val dx = tx - st.x; val dy = ty - st.y; val dist = hypot(dx, dy)
                if (dist < 6f * d) { begin(brain.next()); return }
                if (abs(dx) > 2f * d) st.facing = if (dx > 0) 1 else -1
                val want = max(0.25f, min(1f, dist / (80f * d)))
                st.speed += (want - st.speed) * min(1f, dt * 3f)
                val v = st.speed * 85f * d
                st.x += dx / dist * v * dt; st.y += dy / dist * v * dt
            }
            Behavior.DRAGGED -> {
                st.x += (fx - st.x) * min(1f, dt * 16f); st.y += (fy - st.y) * min(1f, dt * 16f)
                st.speed += (0f - st.speed) * min(1f, dt * 6f)
            }
            else -> st.speed += (0f - st.speed) * min(1f, dt * 6f)
        }
        if (brain.tick(dt)) begin(brain.next())
        renderer.update(st, dt)
    }

    override fun onDraw(canvas: Canvas) {
        if (!ready) { postInvalidateOnAnimation(); return }
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.05f, (now - last) / 1e9f); last = now
        step(dt)
        bg.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), curTop, curBot, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        bg.shader = null; bg.color = 0x33FFFFFF
        canvas.drawRoundRect(-40f * d, height * 0.45f, width + 40f * d, height + 40f * d, 60f * d, 60f * d, bg)
        renderer.draw(canvas, st)
        val per = brain.period()
        hud.color = if (per == Period.NIGHT) 0xCCFFFFFF.toInt() else 0x99000000.toInt()
        val label = per.name.lowercase().replaceFirstChar { it.uppercase() } + if (brain.timeMode < 0) " (auto)" else ""
        canvas.drawText("Lolly · ${st.behavior.name.replace('_', ' ').lowercase()} · $label", width / 2f, 60f * d, hud)
        canvas.drawText("tap top text to change time · touch or drag Lolly", width / 2f, height - 24f * d, hud)
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (e.y < 100f * d) { brain.cycleTimeMode(); return true }
                pressed = renderer.contains(st, e.x, e.y)
                if (pressed) { dragging = false; downX = e.x; downY = e.y; offX = st.x - e.x; offY = st.y - e.y }
            }
            MotionEvent.ACTION_MOVE -> if (pressed) {
                if (!dragging && hypot(e.x - downX, e.y - downY) > slop) { dragging = true; begin(Behavior.DRAGGED) }
                if (dragging) {
                    fx = (e.x + offX).coerceIn(40f * d, width - 40f * d)
                    fy = (e.y + offY).coerceIn(180f * d, height - 30f * d)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (pressed) begin(Behavior.REACT)
                pressed = false; dragging = false
            }
        }
        return true
    }
}
