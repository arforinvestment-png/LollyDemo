package com.lolly.demo

import android.content.Context
import android.graphics.*
import kotlin.math.min

/**
 * Draws the real Lolly from PNG frames in assets/lolly/<folder>/<name>_01.png, _02.png ...
 * Behaviors without frames use the idle frames; with no idle frames at all, the [fallback] shapes are drawn.
 * Frames: square, facing right, feet on the bottom line at [feetY], horizontally centered.
 */
class SpriteRenderer(ctx: Context, private val d: Float, private val fallback: CharacterRenderer) : CharacterRenderer {
    private val size = 190f * d                 // on-screen size of one square frame
    private val feetY = 0.92f                   // feet baseline as a fraction of frame height
    private val folders = mapOf(
        Behavior.IDLE to "idle", Behavior.WALK to "walk", Behavior.SIT to "sit", Behavior.SLEEP to "sleep",
        Behavior.PLAY to "play", Behavior.LOOK_AROUND to "look", Behavior.REACT to "react", Behavior.DRAGGED to "drag"
    )
    private val fps = mapOf(
        Behavior.IDLE to 4f, Behavior.WALK to 8f, Behavior.SIT to 3f, Behavior.SLEEP to 2f,
        Behavior.PLAY to 8f, Behavior.LOOK_AROUND to 4f, Behavior.REACT to 10f, Behavior.DRAGGED to 6f
    )
    private val frames = HashMap<Behavior, List<Bitmap>>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x30000000 }
    private val dst = RectF()
    private var lastB: Behavior? = null
    private var acc = 0f

    init {
        for ((b, f) in folders) {
            try {
                val names = ctx.assets.list("lolly/$f")?.filter { it.endsWith(".png") }?.sorted() ?: continue
                val list = names.mapNotNull { n -> ctx.assets.open("lolly/$f/$n").use { BitmapFactory.decodeStream(it) } }
                if (list.isNotEmpty()) frames[b] = list
            } catch (e: Exception) { /* missing folder: skip */ }
        }
    }

    override fun contains(s: CharacterState, px: Float, py: Float) = fallback.contains(s, px, py)

    override fun update(s: CharacterState, dt: Float) {
        fallback.update(s, dt)
        if (s.behavior != lastB) { lastB = s.behavior; acc = 0f }
        val speedScale = if (s.behavior == Behavior.WALK) 0.4f + 0.6f * s.speed else 1f
        acc += dt * (fps[s.behavior] ?: 6f) * speedScale
    }

    override fun draw(c: Canvas, s: CharacterState) {
        val list = frames[s.behavior] ?: frames[Behavior.IDLE]
        if (list == null) { fallback.draw(c, s); return }
        val n = list.size
        val i = if (s.behavior == Behavior.REACT) min(n - 1, acc.toInt()) else acc.toInt() % n   // react plays once
        val sw = 36f * d
        c.drawOval(s.x - sw, s.y - 6f * d, s.x + sw, s.y + 6f * d, shadow)
        c.save()
        if (s.facing < 0) c.scale(-1f, 1f, s.x, s.y)
        dst.set(s.x - size / 2f, s.y - size * feetY, s.x + size / 2f, s.y + size * (1f - feetY))
        c.drawBitmap(list[i], null, dst, paint)
        c.restore()
    }
}
