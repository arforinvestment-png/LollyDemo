package com.lolly.demo

import android.graphics.Canvas

/** What the renderer needs to know. A future PNG-sprite renderer uses exactly the same state. */
class CharacterState(
    var x: Float = 0f, var y: Float = 0f,      // feet position in pixels
    var facing: Int = 1,
    var behavior: Behavior = Behavior.IDLE,
    var time: Float = 0f,                       // seconds spent in the current behavior
    var speed: Float = 0f                       // 0..1 walking speed
)

interface CharacterRenderer {
    fun update(s: CharacterState, dt: Float)
    fun draw(c: Canvas, s: CharacterState)
    fun contains(s: CharacterState, px: Float, py: Float): Boolean
}
