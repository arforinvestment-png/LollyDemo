package com.lolly.demo

import android.graphics.*
import kotlin.math.*
import kotlin.random.Random

/** Temporary Lolly drawn from code shapes. Pose values are smoothed, so behaviors blend instead of snapping. */
class ShapeRenderer(private val d: Float) : CharacterRenderer {
    private val sc = d * 1.05f
    private val pi = Math.PI.toFloat()
    private val hair = 0xFF7A4028.toInt(); private val amber = 0xFFD88B32.toInt(); private val mustard = 0xFFF6C444.toInt()
    private val ivory = 0xFFF0E6D2.toInt(); private val peach = 0xFFEFAF91.toInt(); private val boot = 0xFF885638.toInt()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; color = boot }
    private val rf = RectF(); private val path = Path()
    private var phase = 0f; private var blink = 3f; private var clock = 0f
    private var bob = 0f; private var lie = 0f; private var sit = 0f; private var head = 0f
    private var eye = 1f; private var leg = 0f; private var arm = 0f; private var mouth = 0f; private var tilt = 0f

    override fun contains(s: CharacterState, px: Float, py: Float) =
        abs(px - s.x) < 70f * sc && py < s.y + 10f * sc && py > s.y - 160f * sc

    override fun update(s: CharacterState, dt: Float) {
        clock += dt
        phase += dt * (3f + 7f * s.speed)
        blink -= dt; if (blink < -0.14f) blink = 2f + Random.nextFloat() * 3f
        val t = s.time
        var tBob = 0f; var tLie = 0f; var tSit = 0f; var tHead = 0f; var tEye = 1f
        var tLeg = 0f; var tArm = 0f; var tMouth = 0f; var tTilt = 0f
        when (s.behavior) {
            Behavior.IDLE -> tBob = sin(t * 2f) * 1.5f
            Behavior.WALK -> { tLeg = s.speed; tBob = abs(sin(phase)) * 5f * s.speed }
            Behavior.SIT -> { tSit = 1f; tHead = sin(t * 0.8f) * 0.25f }
            Behavior.SLEEP -> { tLie = 1f; tEye = 0f; tBob = sin(t * 1.5f) }
            Behavior.PLAY -> { tBob = abs(sin(t * 5f)) * 26f; tArm = 1f; tMouth = 0.6f; tTilt = sin(t * 5f) * 6f }
            Behavior.LOOK_AROUND -> tHead = sin(t * 1.7f)
            Behavior.REACT -> { tBob = max(0f, sin(min(t, 0.5f) * pi / 0.5f)) * 30f; tArm = 1f; tMouth = 1f; tEye = 1.2f }
            Behavior.DRAGGED -> { tBob = 14f; tLeg = 0.8f; tEye = 1.2f; tMouth = 0.8f; tArm = 1f; tTilt = sin(t * 6f) * 8f }
        }
        val k = 1f - exp(-dt * 9f); val kb = 1f - exp(-dt * 20f)
        bob += (tBob - bob) * kb; lie += (tLie - lie) * k; sit += (tSit - sit) * k; head += (tHead - head) * k
        eye += (tEye - eye) * k; leg += (tLeg - leg) * k; arm += (tArm - arm) * k
        mouth += (tMouth - mouth) * k; tilt += (tTilt - tilt) * k
    }

    private fun circle(c: Canvas, x: Float, y: Float, r: Float, col: Int) { fill.color = col; c.drawCircle(x, y, r, fill) }
    private fun limb(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, col: Int) {
        line.strokeWidth = w; line.color = col; c.drawLine(x1, y1, x2, y2, line)
    }

    override fun draw(c: Canvas, s: CharacterState) {
        fill.color = 0x30000000
        val sw = (34f - bob * 0.4f + lie * 22f) * sc
        c.drawOval(s.x - sw, s.y - 6f * sc, s.x + sw, s.y + 6f * sc, fill)

        c.save()
        c.translate(s.x, s.y - bob * sc)
        c.scale(s.facing * sc, sc)
        c.translate(-lie * 50f, -lie * 30f)
        c.rotate(lie * 90f + tilt)

        // legs
        for (i in 0..1) {
            val hx = if (i == 0) -10f else 10f; val hy = -30f + sit * 16f
            val ph = phase + i * pi
            val fx = hx + sin(ph) * 14f * leg * (1f - sit) + 26f * sit
            val fy = -max(0f, cos(ph)) * 8f * leg * (1f - sit) - 4f * sit
            limb(c, hx, hy, fx, fy, 11f, peach); circle(c, fx, fy, 6.5f, boot)
        }
        c.save(); c.translate(0f, sit * 16f)
        val cx = head * 7f; val cy = -104f
        // back hair + buns
        circle(c, cx, cy, 38f, hair); circle(c, cx - 34f, cy - 24f, 13f, hair); circle(c, cx + 34f, cy - 24f, 13f, hair)
        // dress + belt + collar
        fill.color = mustard; c.drawRoundRect(-22f, -80f, 22f, -30f, 16f, 16f, fill)
        fill.color = amber; c.drawRect(-22f, -58f, 22f, -52f, fill)
        fill.color = ivory; c.drawRoundRect(-12f, -82f, 12f, -72f, 6f, 6f, fill)
        // arms
        for (i in 0..1) {
            val sd = if (i == 0) -1f else 1f
            val hx = sd * (26f + 12f * arm)
            val hy = -42f + (-58f) * arm + sin(phase + i * pi) * 8f * leg * (1f - arm)
            limb(c, sd * 22f, -70f, hx, hy, 9f, peach); circle(c, hx, hy, 6f, peach)
        }
        // face
        circle(c, cx, cy, 33f, peach)
        fill.color = hair
        rf.set(cx - 36f, cy - 38f, cx + 36f, cy + 20f); c.drawArc(rf, 180f, 180f, true, fill)
        c.drawRoundRect(cx - 38f, cy - 14f, cx - 26f, cy + 22f, 6f, 6f, fill)
        c.drawRoundRect(cx + 26f, cy - 14f, cx + 38f, cy + 22f, 6f, 6f, fill)
        circle(c, cx + 24f, cy - 36f, 7f, amber); circle(c, cx + 36f, cy - 32f, 7f, amber); circle(c, cx + 30f, cy - 34f, 4f, mustard)
        circle(c, cx - 21f + head * 3f, cy + 15f, 6f, 0x55D88B32); circle(c, cx + 21f + head * 3f, cy + 15f, 6f, 0x55D88B32)
        val e = if (blink < 0f) 0f else eye
        for (sd in intArrayOf(-1, 1)) {
            val ex = cx + sd * 12f + head * 5f; val ey = cy + 4f
            if (e < 0.25f) {
                line.color = boot; line.strokeWidth = 2.5f; rf.set(ex - 6f, ey - 4f, ex + 6f, ey + 4f); c.drawArc(rf, 0f, 180f, false, line)
            } else {
                fill.color = boot; c.drawOval(ex - 5f, ey - 7f * e, ex + 5f, ey + 7f * e, fill)
                circle(c, ex + 1.5f, ey - 3f * e, 2f, ivory)
            }
        }
        val mx = cx + head * 3f; val my = cy + 20f
        if (mouth < 0.2f) {
            line.color = boot; line.strokeWidth = 2.5f; rf.set(mx - 5f, my - 4f, mx + 5f, my + 3f); c.drawArc(rf, 20f, 140f, false, line)
        } else { fill.color = boot; c.drawOval(mx - 4f, my - 3f, mx + 4f, my - 3f + 10f * mouth, fill) }
        c.restore(); c.restore()

        // extras in screen space (not mirrored)
        when (s.behavior) {
            Behavior.SLEEP -> for (i in 0..2) {
                val u = (clock * 0.5f + i / 3f) % 1f
                txt.textSize = d * (12f + 14f * u); txt.alpha = ((1f - u) * 255).toInt()
                c.drawText("z", s.x + s.facing * (55f + u * 25f) * sc, s.y - (50f + u * 60f) * sc, txt)
            }
            Behavior.PLAY -> {
                val by = s.y - 10f * sc - abs(sin(s.time * 5f + 1f)) * 40f * sc
                circle(c, s.x + s.facing * 58f * sc, by, 9f * sc, amber); circle(c, s.x + s.facing * 56f * sc, by - 3f * sc, 3f * sc, ivory)
            }
            Behavior.REACT -> {
                val hy = s.y - (175f + s.time * 25f) * sc; val r = 9f * sc
                path.reset(); path.moveTo(s.x, hy + r * 0.9f)
                path.cubicTo(s.x - r * 1.6f, hy - r * 0.2f, s.x - r * 0.7f, hy - r * 1.3f, s.x, hy - r * 0.4f)
                path.cubicTo(s.x + r * 0.7f, hy - r * 1.3f, s.x + r * 1.6f, hy - r * 0.2f, s.x, hy + r * 0.9f)
                fill.color = 0xFFE8627A.toInt(); c.drawPath(path, fill)
            }
            else -> {}
        }
    }
}
