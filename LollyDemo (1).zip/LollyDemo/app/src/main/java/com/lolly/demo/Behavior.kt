package com.lolly.demo

import java.util.Calendar
import kotlin.random.Random

enum class Behavior { IDLE, WALK, SIT, SLEEP, PLAY, LOOK_AROUND, REACT, DRAGGED }
enum class Period { DAY, EVENING, NIGHT }

/** Pure logic: picks the next behavior. Knows nothing about drawing, so any renderer can sit on top. */
class Brain {
    var timeMode = -1                 // -1 = real clock, otherwise Period.ordinal (for testing)
    var current = Behavior.IDLE
        private set
    private var left = 2f

    fun period(): Period {
        if (timeMode >= 0) return Period.values()[timeMode]
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when { h >= 22 || h < 6 -> Period.NIGHT; h >= 18 -> Period.EVENING; else -> Period.DAY }
    }

    fun cycleTimeMode() { timeMode = if (timeMode >= Period.values().size - 1) -1 else timeMode + 1 }

    fun tick(dt: Float): Boolean {
        if (current == Behavior.DRAGGED) return false
        left -= dt
        return left <= 0f
    }

    fun start(b: Behavior) { current = b; left = duration(b) }

    fun next(): Behavior {
        val p = period()
        val options = Behavior.values().filter {
            it != current && weight(it, p) > 0f && !(it == Behavior.SLEEP && current == Behavior.REACT)
        }
        var r = Random.nextFloat() * options.sumOf { weight(it, p).toDouble() }.toFloat()
        for (o in options) { r -= weight(o, p); if (r <= 0f) return o }
        return options.last()
    }

    private fun weight(b: Behavior, p: Period): Float = when (b) {
        Behavior.IDLE -> 2f
        Behavior.WALK -> when (p) { Period.DAY -> 3f; Period.EVENING -> 1.5f; Period.NIGHT -> 0.3f }
        Behavior.SIT -> when (p) { Period.DAY -> 1f; Period.EVENING -> 2.5f; Period.NIGHT -> 2f }
        Behavior.SLEEP -> when (p) { Period.DAY -> 0.3f; Period.EVENING -> 1f; Period.NIGHT -> 6f }
        Behavior.PLAY -> when (p) { Period.DAY -> 3f; Period.EVENING -> 1.5f; Period.NIGHT -> 0.2f }
        Behavior.LOOK_AROUND -> 2f
        else -> 0f
    }

    private fun r(a: Float, b: Float) = a + Random.nextFloat() * (b - a)
    private fun duration(b: Behavior) = when (b) {
        Behavior.IDLE -> r(2f, 4f); Behavior.WALK -> 12f; Behavior.SIT -> r(4f, 7f)
        Behavior.SLEEP -> r(8f, 14f); Behavior.PLAY -> r(4f, 6f); Behavior.LOOK_AROUND -> r(3f, 5f)
        Behavior.REACT -> 1.3f; Behavior.DRAGGED -> 0f
    }
}
