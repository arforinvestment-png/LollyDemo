Put Lolly frames here: idle/ walk/ sit/ sleep/ play/ look/ react/ drag/ (idle_01.png, idle_02.png ...)
